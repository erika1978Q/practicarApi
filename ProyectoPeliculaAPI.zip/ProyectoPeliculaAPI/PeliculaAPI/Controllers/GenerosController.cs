﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PeliculaAPI.DTOs;
using PeliculaAPI.Entidades;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PeliculaAPI.Controllers
{
    [ApiController]
    [Route("api/generos")]
    public class GenerosController : CustomBaseController
    {
        //private readonly ApplicationDbContext context2;
        //private readonly IMapper mapper2;

        // GET: api/<controller>
        public GenerosController(ApplicationDbContext context,IMapper mapper):base(context,mapper)
        {
            //this.context2 = context;
            //this.mapper2 = mapper;
        }
        [HttpGet]
        public async Task<ActionResult<List<GeneroDTO>>>Get()
        {
            return await Get<Genero, GeneroDTO>();   
            //var entidades=await context2.Generos.ToListAsync();
            //var dtos = mapper2.Map<List<GeneroDTO>>(entidades);
            //return dtos;
        }

        // GET api/<controller>/5
        [HttpGet("{id:int}",Name ="obtenerGenero")]
        public async Task<ActionResult<GeneroDTO>> Get(int id)
        {
            //var entidad = await context2.Generos.FirstOrDefaultAsync(x => x.Id == id);
            //if (entidad==null)
            //{
            //    return NotFound();
            //}
            //var dto = mapper2.Map<GeneroDTO>(entidad);
            //return dto;

            return await Get<Genero, GeneroDTO>(id);
        }

        // POST api/<controller>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody]GeneroCreacionDTO generoCreacionDTO)
        {
            //var entidad = mapper2.Map<Genero>(generoCreacionDTO);
            //    context2.Add(entidad);
            //await context2.SaveChangesAsync();
            //var generoDTO = mapper2.Map<GeneroDTO>(entidad);
            //return new CreatedAtRouteResult("obtenerGenero", new { id = generoDTO.Id }, generoDTO);

            return await Post<GeneroCreacionDTO, Genero, GeneroDTO>(generoCreacionDTO, "obtenerGenero"); 
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody]GeneroCreacionDTO generoCreacionDTO)
        {
            //var entidad = mapper2.Map<Genero>(generoCreacionDTO);
            //entidad.Id = id;
            //context2.Entry(entidad).State = EntityState.Modified;
            //await context2.SaveChangesAsync();
            //return NoContent();
            return await Put<GeneroCreacionDTO, Genero>(id, generoCreacionDTO);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            //var existe = await context2.Generos.AnyAsync(x => x.Id == id);
            //if (!existe)
            //{
            //    return NotFound();
            //}
            //context2.Remove(new Genero() { Id = id });
            //await context2.SaveChangesAsync();
            //return NoContent();

            return await Delete<Genero>(id);
        }
    }
}
